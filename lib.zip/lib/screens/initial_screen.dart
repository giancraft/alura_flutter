import 'package:flutter/material.dart';
import 'package:projeto_alura/components/task.dart';

class InitialScreen extends StatefulWidget {
  const InitialScreen({super.key});

  @override
  State<InitialScreen> createState() => _InicialScreenState();
}

class _InicialScreenState extends State<InitialScreen> {
  bool opacidade = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          leading: Container(),
          title: const Text('Tarefas'),
        ),
        body: AnimatedOpacity(
          opacity: (opacidade) ? 1 : 0,
          duration: const Duration(milliseconds: 800),
          child: ListView(
            children: const [
              Task('Aprender Flutter', 'https://pbs.twimg.com/media/Eu7m692XIAEvxxP?format=png&name=large', 3),
              Task('Andar de Bike', 'https://images.pexels.com/photos/161172/cycling-bike-trail-sport-161172.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', 2),
              Task('Meditar', 'https://manhattanmentalhealthcounseling.com/wp-content/uploads/2019/06/Top-5-Scientific-Findings-on-MeditationMindfulness-881x710.jpeg', 5),
              Task('Minecraft', 'https://static.wikia.nocookie.net/minecraft_gamepedia/images/3/3d/Grass_Block_BE1.png/revision/latest?cb=20200830155913', 1),
              Task('FABTEC', 'https://i.pinimg.com/736x/c3/92/51/c392517600df7b09091fbc1946ba2e86.jpg', 5),
              Task('Alura', 'https://yt3.googleusercontent.com/W7GokEE6ydjZFa_Tpz6yvSsDlVPTe7d4yTsJqKXy1Gbhu1BGXCfKJ_I-_TzOq37m8R9S97kQ=s900-c-k-c0x00ffffff-no-rj', 2),
              Task('BCC', 'https://img.freepik.com/vetores-premium/ciencia-da-computacao_9206-762.jpg', 5),
              SizedBox(height: 80,)
            ],
          ),
        ),
        floatingActionButton: FloatingActionButton(onPressed: (){
          setState(() {
            opacidade = !opacidade;
          });
        },
        child: const Icon(Icons.remove_red_eye),
        ),
      );
  }
}